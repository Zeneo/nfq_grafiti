<?php
App::uses('Controller', 'Controller');

class BasicsController extends AppController {

	var $helpers = array ('Html','Form');
		
}
?>