<?php
    class Index extends AppModel {
		var $useTable = false;
		var $helpers = array ('Html','Form');
		public $name = 'Index';
		
    }
?>